<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="cozy_farm_sampler_64" tilewidth="64" tileheight="64" tilecount="32" columns="16">
 <image source="../atlas/cozy_farm_atlas_64.png" width="1024" height="128"/>
 <wangsets>
  <wangset name="Cozy Farm sampler" type="corner" tile="-1">
   <wangcolor name="grass" color="#88aa66" tile="0" probability="1"/>
   <wangcolor name="path" color="#aa6644" tile="4" probability="1"/>
   <wangtile tileid="0" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="1" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="2" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="3" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="4" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="5" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="6" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="7" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="16" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="17" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="18" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="19" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="20" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="21" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="22" wangid="0,2,0,1,0,2,0,1"/>
   <wangtile tileid="23" wangid="0,2,0,2,0,2,0,1"/>
   <wangtile tileid="24" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="25" wangid="0,1,0,2,0,1,0,2"/>
   <wangtile tileid="26" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="27" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="28" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="29" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="30" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="31" wangid="0,2,0,2,0,2,0,2"/>
  </wangset>
 </wangsets>
</tileset>
