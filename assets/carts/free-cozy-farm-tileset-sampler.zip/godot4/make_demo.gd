extends SceneTree
# Rebuilds res://demo.tscn from res://demo_map.json (terrain name at every tile CORNER, (H+1) x (W+1)).
# Each cell gets the tile whose four corner terrains match - the exact, mismatch-free way to place
# corner (Wang) tiles from code. Run: godot --headless --path . --script res://make_demo.gd

const TL = TileSet.CELL_NEIGHBOR_TOP_LEFT_CORNER
const TR = TileSet.CELL_NEIGHBOR_TOP_RIGHT_CORNER
const BL = TileSet.CELL_NEIGHBOR_BOTTOM_LEFT_CORNER
const BR = TileSet.CELL_NEIGHBOR_BOTTOM_RIGHT_CORNER

func _init():
	var ts: TileSet = load("res://cozy_farm_tileset_64.tres")
	var src: TileSetAtlasSource = ts.get_source(0)
	var names = []
	for i in ts.get_terrains_count(0):
		names.append(ts.get_terrain_name(0, i))
	var index := {}
	for i in src.get_tiles_count():
		var co = src.get_tile_id(i)
		var d = src.get_tile_data(co, 0)
		var key = "%d,%d,%d,%d" % [d.get_terrain_peering_bit(TL), d.get_terrain_peering_bit(TR), d.get_terrain_peering_bit(BL), d.get_terrain_peering_bit(BR)]
		if not index.has(key):
			index[key] = []
		index[key].append(co)
	var g = JSON.parse_string(FileAccess.get_file_as_string("res://demo_map.json"))
	var H = g.size() - 1
	var W = g[0].size() - 1
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var layer := TileMapLayer.new()
	layer.name = "Map"
	layer.tile_set = ts
	var missing := 0
	for y in H:
		for x in W:
			var key = "%d,%d,%d,%d" % [names.find(g[y][x]), names.find(g[y][x + 1]), names.find(g[y + 1][x]), names.find(g[y + 1][x + 1])]
			if index.has(key):
				var opts = index[key]
				layer.set_cell(Vector2i(x, y), 0, opts[rng.randi_range(0, opts.size() - 1)])
			else:
				missing += 1
	var mis := 0
	for y in H:
		for x in W:
			var c := Vector2i(x, y)
			var d = layer.get_cell_tile_data(c)
			var r = layer.get_cell_tile_data(c + Vector2i(1, 0))
			var b = layer.get_cell_tile_data(c + Vector2i(0, 1))
			if r and (d.get_terrain_peering_bit(TR) != r.get_terrain_peering_bit(TL) or d.get_terrain_peering_bit(BR) != r.get_terrain_peering_bit(BL)):
				mis += 1
			if b and (d.get_terrain_peering_bit(BL) != b.get_terrain_peering_bit(TL) or d.get_terrain_peering_bit(BR) != b.get_terrain_peering_bit(TR)):
				mis += 1
	print("demo cells=", W * H, " missing=", missing, " corner_mismatch=", mis)
	var root := Node2D.new()
	root.name = "Demo"
	root.add_child(layer)
	layer.owner = root
	var cam := Camera2D.new()
	cam.name = "Camera2D"
	cam.position = Vector2(W * 32, H * 32)
	cam.zoom = Vector2(0.6, 0.6)
	root.add_child(cam)
	cam.owner = root
	var scene := PackedScene.new()
	scene.pack(root)
	print("save demo err=", ResourceSaver.save(scene, "res://demo.tscn"))
	quit()
