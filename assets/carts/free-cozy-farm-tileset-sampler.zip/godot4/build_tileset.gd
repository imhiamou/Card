extends SceneTree

const COLORS = [Color(0.55,0.75,0.45), Color(0.25,0.45,0.2), Color(0.95,0.8,0.5), Color(0.95,0.95,1.0),
	Color(0.55,0.5,0.45), Color(0.4,0.5,0.3), Color(0.55,0.85,0.9), Color(0.3,0.45,0.65)]

func _init():
	var layout = JSON.parse_string(FileAccess.get_file_as_string("res://atlas/atlas_layout.json"))
	var names = layout["terrains"]
	for s in [64, 128]:
		var ts = TileSet.new()
		ts.tile_size = Vector2i(s, s)
		ts.add_terrain_set(0)
		ts.set_terrain_set_mode(0, TileSet.TERRAIN_MODE_MATCH_CORNERS)
		for i in names.size():
			ts.add_terrain(0, i)
			ts.set_terrain_name(0, i, names[i])
			ts.set_terrain_color(0, i, COLORS[i])
		var src = TileSetAtlasSource.new()
		src.texture = load("res://atlas/cozy_farm_atlas_%d.png" % s)
		src.texture_region_size = Vector2i(s, s)
		ts.add_source(src, 0)
		for t in layout["tiles"]:
			var c = Vector2i(int(t["col"]), int(t["row"]))
			src.create_tile(c)
			var d = src.get_tile_data(c, 0)
			d.terrain_set = 0
			d.terrain = names.find(t["center"])
			var k = t["corners"]
			d.set_terrain_peering_bit(TileSet.CELL_NEIGHBOR_TOP_LEFT_CORNER, names.find(k[0]))
			d.set_terrain_peering_bit(TileSet.CELL_NEIGHBOR_TOP_RIGHT_CORNER, names.find(k[1]))
			d.set_terrain_peering_bit(TileSet.CELL_NEIGHBOR_BOTTOM_LEFT_CORNER, names.find(k[2]))
			d.set_terrain_peering_bit(TileSet.CELL_NEIGHBOR_BOTTOM_RIGHT_CORNER, names.find(k[3]))
		var err = ResourceSaver.save(ts, "res://cozy_farm_tileset_%d.tres" % s)
		print("saved tileset ", s, " err=", err, " tiles=", src.get_tiles_count())
	quit()
